
Please reference the "Your First Scenario" tutorial for guidance on how to get started with the included template:

https://www.katacoda.community/